"use server";
import { query } from "@/lib/db";
import { redirect } from "next/navigation";

export async function login(formData: FormData) {
  const email = formData.get("email");
  const password = formData.get("password");

  // Query the database for the user
  const { rows } = await query("SELECT * FROM users WHERE email = $1", [email]);
  const user = rows[0];

  if (user && user.password_hash === password) {
    // In a real app, you would set a cookie/session here
    console.log("Login successful!");
    redirect("/admin/dashboard");
  } else {
    throw new Error("Invalid credentials");
  }
}