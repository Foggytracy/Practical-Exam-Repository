"use client";
import { useState } from "react";
import { login } from "@/app/actions/auth";

export default function LoginPage() {
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(formData: FormData) {
    setLoading(true);
    setError("");
    const result = await login(formData);
    if (result?.error) {
      setError(result.error);
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f3f3f3] p-4">
      <form action={handleSubmit} className="bg-white p-8 border-2 border-black rounded shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 uppercase tracking-tighter">Admin Login</h1>
        
        {error && (
          <div className="bg-red-100 border-2 border-red-500 p-3 mb-4 text-red-700 text-sm font-bold">
            {error}
          </div>
        )}
        
        <div className="mb-4">
          <label className="block text-xs font-bold mb-1 uppercase">Email</label>
          <input name="email" type="email" className="w-full p-3 border-2 border-black rounded focus:outline-[#b9ff66]" required />
        </div>
        
        <div className="mb-6">
          <label className="block text-xs font-bold mb-1 uppercase">Password</label>
          <input name="password" type="password" className="w-full p-3 border-2 border-black rounded focus:outline-[#b9ff66]" required />
        </div>
        
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-[#b9ff66] border-2 border-black font-bold py-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] transition-all disabled:bg-gray-200"
        >
          {loading ? "Verifying..." : "Login to Dashboard"}
        </button>
      </form>
    </div>
  );
}