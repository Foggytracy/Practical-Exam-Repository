"use server";

import { query } from "@/lib/db";
import { cookies } from "next/headers";
import jwt from "jsonwebtoken";
import { redirect } from "next/navigation";

const JWT_SECRET = process.env.JWT_SECRET || "your_super_secret_exam_key_123";

export async function login(formData: FormData) {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  // 1. Fetch user - using password_hash to match your schema
  const { rows } = await query("SELECT * FROM users WHERE email = $1", [email]);
  const user = rows[0];

  // 2. Verify credentials
  if (user && user.password_hash === password) {
    // 3. Create JWT
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    // 4. Set Cookie
    const cookieStore = await cookies();
    cookieStore.set("admin_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
    });

    redirect("/admin/dashboard");
  } else {
    return { error: "Invalid credentials" };
  }
}

export async function logout() {
  const cookieStore = await cookies();
  cookieStore.delete("admin_token");
  // Redirect to login ensures the client-side router resets
  redirect("/login");
}