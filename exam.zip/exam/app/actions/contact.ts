"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";

export async function submitContactForm(formData: FormData) {
  const name = formData.get("name") as string;
  const email = formData.get("email") as string;
  const message = formData.get("message") as string;

  try {
    await query(
      "INSERT INTO contact_submissions (name, email, message) VALUES ($1, $2, $3)",
      [name, email, message]
    );
    revalidatePath("/admin/messages");
    return { success: true };
  } catch (error: any) {
    console.error("Submission Error:", error.message);
    return { success: false, error: "Failed to send message." };
  }
}

export async function updateMessageStatus(id: string, status: 'read' | 'archived') {
  await query(
    "UPDATE contact_submissions SET status = $1, updated_at = NOW() WHERE id = $2",
    [status, id]
  );
  revalidatePath("/admin/messages");
}