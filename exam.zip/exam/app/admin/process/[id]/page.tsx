import { query } from "@/lib/db";
import { updateProcessStep } from "../action";
import Link from "next/link";

// Note the Promise type for Next.js 15
export default async function EditProcessPage({ 
  params 
}: { 
  params: Promise<{ id: string }> 
}) {
  // 1. Await the params to get the ID
  const { id } = await params;

  // 2. Fetch the specific row
  const { rows } = await query(
    "SELECT * FROM working_processes WHERE id = $1", 
    [id]
  );
  const step = rows[0];

  // 3. Safety check: If no data, show a message
  if (!step) {
    return (
      <div className="p-20 text-center">
        <h1 className="text-2xl font-bold">Step not found</h1>
        <p className="mb-4">The ID {id} does not exist in the database.</p>
        <Link href="/admin/process" className="text-blue-600 underline">Return to List</Link>
      </div>
    );
  }

  // 4. If data exists, show the form
  return (
    <div className="p-8 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Edit Process Step</h1>
        <Link href="/admin/process" className="text-sm font-bold underline">Back</Link>
      </div>

      <form 
        action={updateProcessStep} 
        className="bg-white p-8 border-2 border-black rounded shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-6"
      >
        {/* CRITICAL: This hidden input tells the action which row to update */}
        <input type="hidden" name="id" value={step.id} />
        
        <div>
          <label className="block text-sm font-bold mb-2 uppercase">Step Number</label>
          <input 
            name="step_no" 
            type="number" 
            defaultValue={step.step_no} 
            className="w-full p-3 border-2 border-black rounded font-bold" 
            required 
          />
        </div>

        <div>
          <label className="block text-sm font-bold mb-2 uppercase">Title</label>
          <input 
            name="title" 
            defaultValue={step.title} 
            className="w-full p-3 border-2 border-black rounded" 
            required 
          />
        </div>

        <div>
          <label className="block text-sm font-bold mb-2 uppercase">Description</label>
          <textarea 
            name="description" 
            defaultValue={step.description} 
            className="w-full p-3 border-2 border-black rounded h-40" 
            required 
          />
        </div>
        
        <div className="flex gap-4 pt-4">
          <button type="submit" className="flex-1 bg-[#b9ff66] border-2 border-black font-bold py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all">
            Save Changes
          </button>
          <Link href="/admin/process" className="flex-1 bg-gray-100 border-2 border-black font-bold py-3 text-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all">
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}