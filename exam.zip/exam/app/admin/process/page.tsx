import { query } from "@/lib/db";
import { addProcessStep, deleteProcessStep } from "./action";
import Link from "next/link";

export default async function ManageProcessPage() {
  // 1. Fetch the latest steps from the database
  const { rows: steps } = await query(
    "SELECT * FROM working_processes ORDER BY step_no ASC"
  );

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Manage Working Process</h1>

      {/* --- ADD NEW STEP FORM --- */}
      <section className="mb-12">
        <h2 className="text-lg font-bold mb-4 uppercase tracking-wider">Add New Step</h2>
        <form 
          action={addProcessStep} 
          className="grid grid-cols-12 gap-4 bg-white p-6 border-2 border-black rounded shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
        >
          <div className="col-span-2">
            <label className="block text-xs font-bold mb-1">STEP #</label>
            <input 
              name="step_no" 
              type="number" 
              placeholder="1"
              className="w-full p-2 border-2 border-black rounded" 
              required 
            />
          </div>

          <div className="col-span-4">
            <label className="block text-xs font-bold mb-1">TITLE</label>
            <input 
              name="title" 
              placeholder="e.g. Consultation"
              className="w-full p-2 border-2 border-black rounded" 
              required 
            />
          </div>

          <div className="col-span-6">
            <label className="block text-xs font-bold mb-1">DESCRIPTION</label>
            <input 
              name="description" 
              placeholder="Brief description of the step..."
              className="w-full p-2 border-2 border-black rounded" 
              required 
            />
          </div>
          
          <div className="col-span-12 pt-2">
            <button 
              type="submit" 
              className="bg-[#b9ff66] border-2 border-black font-bold px-8 py-2 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all"
            >
              + Create Step
            </button>
          </div>
        </form>
      </section>

      {/* --- LIST OF STEPS --- */}
      <section>
        <h2 className="text-lg font-bold mb-4 uppercase tracking-wider">Current Steps</h2>
        <div className="space-y-4">
          {steps.map((step) => (
            <div 
              key={step.id} 
              className="grid grid-cols-12 gap-4 items-center p-4 border-2 border-black rounded bg-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
            >
              <div className="col-span-1 flex justify-center">
                <span className="font-bold text-2xl">
                  {step.step_no < 10 ? `0${step.step_no}` : step.step_no}
                </span>
              </div>
              
              <div className="col-span-3">
                <p className="font-bold text-lg">{step.title}</p>
              </div>

              <div className="col-span-5">
                <p className="text-gray-600 truncate">{step.description}</p>
              </div>
              
              <div className="col-span-3 flex gap-6 justify-end pr-4">
                {/* Link to the separate Edit Page */}
                <Link 
                  href={`/admin/process/${step.id}`} 
                  className="text-blue-600 font-bold hover:underline"
                >
                  Edit
                </Link>
                
                {/* Delete functionality via Server Action */}
                <form action={async () => { "use server"; await deleteProcessStep(step.id); }}>
                  <button 
                    type="submit" 
                    className="text-red-500 font-bold hover:underline"
                  >
                    Delete
                  </button>
                </form>
              </div>
            </div>
          ))}

          {steps.length === 0 && (
            <div className="p-10 text-center border-2 border-dashed border-gray-300 rounded">
              <p className="text-gray-500">No process steps found. Add your first one above!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}