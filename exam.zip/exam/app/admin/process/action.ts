"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function addProcessStep(formData: FormData) {
  try {
    const step_no = parseInt(formData.get("step_no") as string);
    const title = formData.get("title") as string;
    const description = formData.get("description") as string;

    await query(
      `INSERT INTO working_processes (step_no, title, description) 
       VALUES ($1, $2, $3)`,
      [step_no, title, description]
    );
  } catch (error) {
    console.error("Database Error:", error);
    throw new Error("Failed to create process step.");
  }

  revalidatePath("/admin/process");
  revalidatePath("/");
  // No redirect needed for "Add" if you want to stay on the same page
}

export async function updateProcessStep(formData: FormData) {
  try {
    const id = formData.get("id") as string;
    const step_no = parseInt(formData.get("step_no") as string);
    const title = formData.get("title") as string;
    const description = formData.get("description") as string;

    await query(
      `UPDATE working_processes 
       SET step_no = $1, title = $2, description = $3, updated_at = NOW() 
       WHERE id = $4`,
      [step_no, title, description, id]
    );
  } catch (error) {
    console.error("Update Error:", error);
    throw new Error("Failed to update process step.");
  }

  revalidatePath("/admin/process");
  revalidatePath("/");
  
  // CRITICAL: redirect MUST be outside the try/catch block
  redirect("/admin/process");
}

export async function deleteProcessStep(id: string) {
  try {
    await query("DELETE FROM working_processes WHERE id = $1", [id]);
  } catch (error) {
    console.error("Delete Error:", error);
    throw new Error("Failed to delete process step.");
  }

  revalidatePath("/admin/process");
  revalidatePath("/");
}