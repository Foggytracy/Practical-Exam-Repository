import Link from "next/link";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { logout } from "@/app/actions/auth";

export const dynamic = "force-dynamic"; 
export const revalidate = 0; 

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // 1. Server-side Protection: If no token, kick them out immediately
  const cookieStore = await cookies();
  const token = cookieStore.get("admin_token");

  if (!token) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen bg-gray-50 text-black">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white p-6 shadow-xl flex flex-col">
        <h2 className="text-xl font-bold mb-8 border-b border-slate-700 pb-4 text-[#b9ff66]">
          Admin Panel
        </h2>
        
        <nav className="space-y-4 flex-1">
          <Link href="/admin/dashboard" className="block hover:text-[#b9ff66] transition-colors">
            Dashboard
          </Link>
          <Link href="/admin/services" className="block hover:text-[#b9ff66] transition-colors">
            Manage Services
          </Link>
          
          <Link href="/admin/case-studies" className="block hover:text-[#b9ff66] transition-colors">
            Manage Case Studies
          </Link>

          <Link href="/admin/process" className="block hover:text-[#b9ff66] transition-colors">
            Manage Processes
          </Link>

          <Link href="/admin/team" className="block hover:text-[#b9ff66] transition-colors">
            Manage Team
          </Link>

          <Link href="/admin/testimonials" className="block hover:text-[#b9ff66] transition-colors">
            Manage Testimonials
          </Link>

          <Link href="/admin/messages" className="block hover:text-[#b9ff66] transition-colors">
            Inbound Messages
          </Link>

          <div className="pt-10 border-t border-slate-700">
            <Link href="/" className="block mb-4 text-slate-400 hover:text-white transition-colors">
              ← View Site
            </Link>
            
            {/* 2. FIXED: Logout now uses a Form + Server Action */}
            <form action={logout}>
              <button 
                type="submit" 
                className="text-red-400 hover:text-red-300 font-medium transition-colors bg-transparent border-none cursor-pointer p-0"
              >
                Logout
              </button>
            </form>
          </div>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-10 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}