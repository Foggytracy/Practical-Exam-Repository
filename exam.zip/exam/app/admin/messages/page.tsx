import { query } from "@/lib/db";
import { updateMessageStatus } from "../../actions/contact";

export default async function AdminInbox() {
  const { rows: messages } = await query(
    "SELECT * FROM contact_submissions ORDER BY created_at DESC"
  );

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-8 uppercase tracking-tighter">Inbound Messages</h1>
      
      <div className="grid gap-6">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`p-6 border-2 border-black rounded bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-opacity ${msg.status === 'archived' ? 'opacity-50' : 'opacity-100'}`}
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className={`text-[10px] font-bold uppercase px-2 py-1 border border-black rounded ${
                  msg.status === 'new' ? 'bg-[#b9ff66]' : 'bg-gray-200'
                }`}>
                  {msg.status}
                </span>
                <h3 className="font-bold text-lg mt-2">{msg.name}</h3>
                <p className="text-sm text-gray-500">{msg.email}</p>
              </div>
              <p className="text-xs text-gray-400">
                {new Date(msg.created_at).toLocaleDateString()}
              </p>
            </div>
            
            <p className="text-gray-700 bg-gray-50 p-4 border border-dashed border-gray-300 rounded mb-4">
              {msg.message}
            </p>

            <div className="flex gap-4">
              {msg.status !== 'read' && (
                <form action={async () => { "use server"; await updateMessageStatus(msg.id, 'read'); }}>
                  <button className="text-xs font-bold hover:underline text-blue-600">Mark as Read</button>
                </form>
              )}
              {msg.status !== 'archived' && (
                <form action={async () => { "use server"; await updateMessageStatus(msg.id, 'archived'); }}>
                  <button className="text-xs font-bold hover:underline text-gray-500">Archive</button>
                </form>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}