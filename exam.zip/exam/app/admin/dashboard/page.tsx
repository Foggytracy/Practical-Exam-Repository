import { query } from "@/lib/db";

export default async function AdminDashboard() {
  // Example of how you will eventually fetch your counts
  // const services = await query("SELECT COUNT(*) FROM services");
  // const team = await query("SELECT COUNT(*) FROM team_members");

  const stats = [
    { label: "Active Services", value: "10", color: "bg-blue-500" },
    { label: "Team Members", value: "8", color: "bg-green-500" },
    { label: "User Queries", value: "45", color: "bg-purple-500" },
  ];

  return (
    <div>
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800">System Overview</h1>
        <p className="text-gray-500">Welcome back, John Lor.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <p className="text-sm font-medium text-gray-500 uppercase">{stat.label}</p>
            <p className="text-4xl font-bold mt-2 text-gray-900">{stat.value}</p>
            <div className={`h-1 w-12 mt-4 ${stat.color} rounded`}></div>
          </div>
        ))}
      </div>

      <div className="mt-10 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
        <div className="flex gap-4">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            Add New Service
          </button>
          <button className="px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition">
            Export Report
          </button>
        </div>
      </div>
    </div>
  );
}