import { query } from "@/lib/db";
import { addTestimonial, deleteTestimonial } from "./action";

export default async function ManageTestimonials() {
  const { rows: data } = await query("SELECT * FROM testimonials ORDER BY created_at DESC");

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-8 uppercase tracking-widest">Testimonials Dashboard</h1>

      {/* Add Form */}
      <form action={addTestimonial} className="bg-white p-6 border-2 border-black rounded shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-12 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1">
            <label className="block text-xs font-bold mb-1">CLIENT NAME</label>
            <input name="name" className="w-full p-2 border-2 border-black rounded" required />
          </div>
          <div className="md:col-span-1">
            <label className="block text-xs font-bold mb-1">ROLE / COMPANY</label>
            <input name="role_company" className="w-full p-2 border-2 border-black rounded" required />
          </div>
          <div className="md:col-span-1">
            <label className="block text-xs font-bold mb-1">RATING (1-5)</label>
            <input name="rating" type="number" min="1" max="5" defaultValue="5" className="w-full p-2 border-2 border-black rounded" required />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">MESSAGE</label>
          <textarea name="message" className="w-full p-2 border-2 border-black rounded h-24" required />
        </div>
        <button type="submit" className="w-full bg-[#b9ff66] border-2 border-black font-bold py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all">
          Publish Testimonial
        </button>
      </form>

      {/* List Display */}
      <div className="grid gap-4">
        {data.map((item) => (
          <div key={item.id} className="flex justify-between items-start p-6 border-2 border-black rounded bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-bold text-lg">{item.name}</p>
                <span className="bg-gray-100 px-2 py-0.5 rounded text-[10px] font-bold border border-black">{item.rating} ★</span>
              </div>
              <p className="text-sm font-medium text-gray-500 mb-2">{item.role_company}</p>
              <p className="text-sm italic text-gray-700 leading-relaxed">"{item.message}"</p>
            </div>
            <form action={async () => { "use server"; await deleteTestimonial(item.id); }}>
              <button className="text-red-500 font-bold hover:underline py-1 px-3 border-2 border-transparent hover:border-red-500 rounded transition-all">
                Delete
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}