"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function addTestimonial(formData: FormData) {
  const name = formData.get("name") as string;
  const role_company = formData.get("role_company") as string;
  const message = formData.get("message") as string;
  const rating = parseInt(formData.get("rating") as string) || 5;

  try {
    await query(
      "INSERT INTO testimonials (name, role_company, message, rating) VALUES ($1, $2, $3, $4)",
      [name, role_company, message, rating]
    );
  } catch (error: any) {
    console.error("Add Testimonial Error:", error.message);
    throw new Error("Failed to add testimonial.");
  }

  revalidatePath("/admin/testimonials");
  revalidatePath("/");
}

export async function deleteTestimonial(id: string) {
  try {
    await query("DELETE FROM testimonials WHERE id = $1", [id]);
    revalidatePath("/admin/testimonials");
    revalidatePath("/");
  } catch (error: any) {
    console.error("Delete Error:", error.message);
  }
}