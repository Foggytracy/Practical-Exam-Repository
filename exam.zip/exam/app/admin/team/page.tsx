import { query } from "@/lib/db";
import { addTeamMember, deleteTeamMember } from "./action";
import Link from "next/link";

export default async function ManageTeam() {
  const { rows: team } = await query("SELECT * FROM team_members ORDER BY created_at DESC");

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-8 uppercase">Team Management</h1>

      <form action={addTeamMember} className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 border-2 border-black rounded shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-12">
        <div>
          <label className="block text-xs font-bold mb-1 uppercase">Name</label>
          <input name="name" className="w-full p-2 border-2 border-black rounded" required />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1 uppercase">Role</label>
          <input name="role" className="w-full p-2 border-2 border-black rounded" required />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs font-bold mb-1 uppercase">Avatar Image</label>
          <input type="file" name="avatar_image" accept="image/*" className="w-full p-2 border-2 border-black rounded bg-white" required />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs font-bold mb-1 uppercase">Experience / Bio</label>
          <textarea name="experience" className="w-full p-2 border-2 border-black rounded h-24" required />
        </div>
        <button type="submit" className="md:col-span-2 bg-[#b9ff66] border-2 border-black font-bold py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all">
          Upload & Add Member
        </button>
      </form>

      <div className="grid gap-4">
        {team.map((member) => (
          <div key={member.id} className="flex justify-between items-center p-4 border-2 border-black rounded bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 border-2 border-black rounded overflow-hidden">
                <img src={member.avatar_url} alt={member.name} className="w-full h-full object-cover" />
              </div>
              <div>
                <p className="font-bold">{member.name}</p>
                <p className="text-sm text-gray-500">{member.role}</p>
              </div>
            </div>
            <div className="flex gap-4">
              <form action={async () => { "use server"; await deleteTeamMember(member.id); }}>
                <button type="submit" className="text-red-500 font-bold hover:underline">Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}