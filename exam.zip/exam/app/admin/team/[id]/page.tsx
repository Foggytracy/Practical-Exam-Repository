import { query } from "@/lib/db";
import { updateTeamMember } from "../action";
import Link from "next/link";

export default async function EditTeamMember({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { rows } = await query("SELECT * FROM team_members WHERE id = $1", [id]);
  const member = rows[0];

  if (!member) return <div className="p-20 text-center font-bold">Member not found.</div>;

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Update {member.name}</h1>
      
      <form action={updateTeamMember} className="bg-white p-8 border-2 border-black rounded shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] space-y-6">
        <input type="hidden" name="id" value={member.id} />
        <input type="hidden" name="existing_avatar" value={member.avatar_url} />
        
        <div className="flex items-center gap-6 p-4 border-2 border-dashed border-black rounded bg-gray-50">
           <div className="w-24 h-24 border-2 border-black rounded overflow-hidden bg-white flex-shrink-0">
              <img src={member.avatar_url} className="w-full h-full object-cover" />
           </div>
           <div className="flex-1">
              <label className="block text-xs font-bold mb-1 uppercase">New Avatar (Optional)</label>
              <input type="file" name="avatar_image" accept="image/*" className="w-full p-2 border-2 border-black rounded bg-white" />
           </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold mb-1 uppercase">Name</label>
            <input name="name" defaultValue={member.name} className="w-full p-2 border-2 border-black rounded" required />
          </div>
          <div>
            <label className="block text-xs font-bold mb-1 uppercase">Role</label>
            <input name="role" defaultValue={member.role} className="w-full p-2 border-2 border-black rounded" required />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold mb-1 uppercase">Experience</label>
          <textarea name="experience" defaultValue={member.experience} className="w-full p-2 border-2 border-black rounded h-32" required />
        </div>
        
        <div className="flex gap-4 pt-4">
          <button type="submit" className="flex-1 bg-[#b9ff66] border-2 border-black font-bold py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all">
            Save Changes
          </button>
          <Link href="/admin/team" className="flex-1 text-center py-3 border-2 border-black rounded font-bold">
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}