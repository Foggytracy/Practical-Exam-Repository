"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import fs from "fs/promises";
import path from "path";

// Helper function to handle local file saving
async function saveFile(file: File) {
  const filename = `${Date.now()}-${file.name.replace(/\s+/g, "_")}`;
  const uploadDir = path.join(process.cwd(), "public/uploads/team");
  await fs.mkdir(uploadDir, { recursive: true });
  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(path.join(uploadDir, filename), buffer);
  return `/uploads/team/${filename}`;
}

export async function addTeamMember(formData: FormData) {
  const name = formData.get("name") as string;
  const role = formData.get("role") as string;
  const experience = formData.get("experience") as string;
  const file = formData.get("avatar_image") as File;

  let avatar_url = "/team/p1.png";
  if (file && file.size > 0) {
    avatar_url = await saveFile(file);
  }

  await query(
    "INSERT INTO team_members (name, role, avatar_url, experience) VALUES ($1, $2, $3, $4)",
    [name, role, avatar_url, experience]
  );

  revalidatePath("/admin/team");
  revalidatePath("/");
}

export async function updateTeamMember(formData: FormData) {
  const id = formData.get("id") as string;
  const name = formData.get("name") as string;
  const role = formData.get("role") as string;
  const experience = formData.get("experience") as string;
  const file = formData.get("avatar_image") as File;
  let avatar_url = formData.get("existing_avatar") as string;

  // Only upload a new file if the user selected one
  if (file && file.size > 0) {
    avatar_url = await saveFile(file);
  }

  await query(
    "UPDATE team_members SET name = $1, role = $2, avatar_url = $3, experience = $4, updated_at = NOW() WHERE id = $5",
    [name, role, avatar_url, experience, id]
  );

  revalidatePath("/admin/team");
  revalidatePath("/");
  redirect("/admin/team");
}

export async function deleteTeamMember(id: string) {
  await query("DELETE FROM team_members WHERE id = $1", [id]);
  revalidatePath("/admin/team");
  revalidatePath("/");
}