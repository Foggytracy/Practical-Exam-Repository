"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";

// CREATE
export async function addService(formData: FormData) {
  const title = formData.get("title");
  const description = formData.get("description");

  await query(
    "INSERT INTO services (title, description) VALUES ($1, $2)",
    [title, description]
  );

  // Refresh the admin list
  revalidatePath("/admin/services"); 
  // FIX: Refresh the landing page so the new service appears!
  revalidatePath("/"); 
}

// DELETE
export async function deleteService(id: number) {
  await query("DELETE FROM services WHERE id = $1", [id]);
  
  // Refresh the admin list
  revalidatePath("/admin/services");
  // FIX: Refresh the landing page so the deleted service disappears!
  revalidatePath("/"); 
}