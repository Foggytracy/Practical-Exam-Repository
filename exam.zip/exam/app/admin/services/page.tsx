import { query } from "@/lib/db";
import { addService, deleteService } from "./action";

export default async function ManageServices() {
  // READ: Fetch all services from PostgreSQL
  const { rows: services } = await query("SELECT * FROM services ORDER BY id DESC");

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-gray-800">Manage Services</h1>

      {/* CREATE: Add Service Form */}
      <section className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-lg font-semibold mb-4">Add New Service</h2>
        <form action={addService} className="flex flex-col gap-4">
          <input
            name="title"
            placeholder="Service Title (e.g. Web Design)"
            className="p-2 border rounded text-black"
            required
          />
          <textarea
            name="description"
            placeholder="Description"
            className="p-2 border rounded text-black"
            required
          />
          <button className="bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
            Save Service
          </button>
        </form>
      </section>

      {/* READ/DELETE: Services Table */}
      <section className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4 font-semibold text-gray-700">Title</th>
              <th className="p-4 font-semibold text-gray-700">Description</th>
              <th className="p-4 font-semibold text-gray-700 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {services.map((service) => (
              <tr key={service.id} className="hover:bg-gray-50">
                <td className="p-4 font-medium text-gray-900">{service.title}</td>
                <td className="p-4 text-gray-600 truncate max-w-xs">{service.description}</td>
                <td className="p-4 text-right">
                  <form action={async () => {
                    "use server";
                    await deleteService(service.id);
                  }}>
                    <button className="text-red-600 hover:underline">Delete</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}