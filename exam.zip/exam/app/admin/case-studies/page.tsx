import { query } from "@/lib/db";
import { addCaseStudy, deleteCaseStudy } from "./action";

export default async function ManageCaseStudies() {
  const { rows } = await query("SELECT * FROM case_studies ORDER BY created_at DESC");

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Manage Case Studies</h1>

      {/* Add Form */}
      <form action={addCaseStudy} className="bg-white p-6 rounded-xl border-2 border-black shadow-brutal mb-12 space-y-4">
        <input name="title" placeholder="Client Name / Project Title" className="w-full p-2 border-2 border-black rounded" required />
        <textarea name="short_description" placeholder="Short Description" className="w-full p-2 border-2 border-black rounded h-24" required />
        <input name="link_url" placeholder="Link URL (Optional)" className="w-full p-2 border-2 border-black rounded" />
        <button type="submit" className="bg-brand-lime px-6 py-2 border-2 border-black font-bold hover:shadow-none transition-all shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          Add Case Study
        </button>
      </form>

      {/* List */}
      <div className="space-y-4">
        {rows.map((study) => (
          <div key={study.id} className="flex justify-between items-center p-4 border-2 border-black rounded bg-gray-50">
            <div>
              <p className="font-bold">{study.title}</p>
              <p className="text-sm text-gray-600">{study.short_description.substring(0, 50)}...</p>
            </div>
            <form action={async () => { "use server"; await deleteCaseStudy(study.id); }}>
               <button className="text-red-500 font-bold hover:underline">Delete</button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}