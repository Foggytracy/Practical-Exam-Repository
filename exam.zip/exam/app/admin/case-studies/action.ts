"use server";

import { query } from "@/lib/db";
import { revalidatePath } from "next/cache";

export async function addCaseStudy(formData: FormData) {
  const title = formData.get("title");
  const short_description = formData.get("short_description");
  const link_url = formData.get("link_url") || "#";
  const cover_image_url = formData.get("cover_image_url") || "/case-studies/default.svg";

  await query(
    `INSERT INTO case_studies (title, short_description, link_url, cover_image_url, is_active) 
     VALUES ($1, $2, $3, $4, TRUE)`,
    [title, short_description, link_url, cover_image_url]
  );

  revalidatePath("/admin/case-studies");
  revalidatePath("/");
}

export async function deleteCaseStudy(id: string) {
  // Use string because your ID is a UUID
  await query("DELETE FROM case_studies WHERE id = $1", [id]);
  revalidatePath("/admin/case-studies");
  revalidatePath("/");
}