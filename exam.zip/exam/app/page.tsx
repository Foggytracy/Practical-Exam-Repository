export const dynamic = 'force-dynamic';

import { query } from "@/lib/db";
// REMOVED: import { useState } from 'react';
import Team from "@/components/Team";
import WorkingProcess from "@/components/WorkingProcess";
import CaseStudies from "@/components/CaseStudies";
import Services from "@/components/Services";
import Navbar from "../components/Navbar";
import TestimonialSlider from "@/components/TestimonialSlider";
import ContactForm from "@/components/ContactForm";

export default async function Home() {
  // REMOVED: const [openStep, setOpenStep] = useState<string | null>("01");

  // This await query works perfectly here because the component is 'async'
  const { rows } = await query("SELECT id, title, description FROM services ORDER BY id ASC");
  const { rows: caseStudies } = await query("SELECT * FROM case_studies ORDER BY id ASC");
  const { rows: processSteps } = await query("SELECT id, step_no, title, description FROM working_processes WHERE is_active = TRUE ORDER BY step_no ASC")
  const { rows: teamMembers } = await query("SELECT * FROM team_members WHERE is_active = TRUE ORDER BY created_at ASC");
  const { rows: testimonials } = await query(
  "SELECT * FROM testimonials WHERE is_active = TRUE ORDER BY created_at DESC"
);
  return (
  
    <main className="max-w-7xl mx-auto px-6">
      <Navbar />
      
      {/* Hero Section */}
      <section className="flex flex-col md:flex-row items-center justify-between py-12 gap-10">
        <div className="md:w-1/2 space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold leading-tight">
            Navigating the <br />
            <span className="bg-brand-lime px-2 rounded-lg">digital landscape</span> <br />
            for success
          </h1>
          <p className="text-lg text-gray-700 max-w-md">
            Our digital marketing agency helps businesses grow and succeed online through a range of services including SEO, PPC, social media marketing, and content creation.
          </p>
          <button className="bg-brand-dark text-white px-8 py-4 rounded-xl text-lg font-medium shadow-brutal hover:bg-brand-lime hover:text-brand-dark transition-all">
            Book a consultation
          </button>
        </div>

        <div className="md:w-1/2 flex justify-center">
             <img src="/Illustration.svg" alt="Logo"  />
        </div>
      </section>

      {/* Logo Cloud Section */}
      <div className="flex flex-wrap justify-between items-center gap-10 py-10 grayscale opacity-80 mt-10">
        <img src="/amazon.svg" alt="Amazon" className="h-6 md:h-12 object-contain" />
        <img src="/dribbble.svg" alt="dribbble" className="h-6 md:h-12 object-contain" />
        <img src="/hubspot.svg" alt="HubSpot" className="h-6 md:h-12 object-contain" />
        <img src="/notion.svg" alt="Notion" className="h-6 md:h-12 object-contain" />
        <img src="/netflix.svg" alt="Netflix" className="h-6 md:h-12 object-contain" />
        <img src="/zoom.svg" alt="Zoom" className="h-6 md:h-12 object-contain" />
      </div>

      <Services dbServices={rows}/>

      {/* Call to Action Section */}
      <section className="mt-[100px] mb-20 px-4 md:px-0">
        <div className="bg-brand-gray rounded-brand p-8 md:p-14 flex flex-col md:flex-row items-center justify-between relative overflow-visible">
          
          <div className="md:w-1/2 space-y-6 z-10">
            <h3 className="text-3xl font-bold">Let's make things happen</h3>
            <p className="text-lg max-w-sm">
              Contact us today to learn more about how our digital 
              marketing services can help your business grow and succeed online.
            </p>
            <button className="bg-brand-dark text-white px-8 py-4 rounded-xl font-medium hover:bg-brand-lime hover:text-brand-dark transition-all shadow-brutal">
              Get your free proposal
            </button>
          </div>

          <div className="hidden md:block md:w-1/2 relative h-full">
            <img 
              src="/CTA Illustration.svg" 
              alt="CTA Graphic" 
              className="absolute w-[500px] max-w-none -top-70 -right-16 z-20"
            />
          </div>
        </div>
      </section>

      <CaseStudies data={caseStudies} />
      <WorkingProcess data={processSteps}/>
      <Team teamData={teamMembers} />
      {/* Dynamic Testimonials Section */}
      <section id="testimonials" className="py-20">
        <div className="px-6 lg:px-20 max-w-[1440px] mx-auto mb-10">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <h2 className="bg-[#b9ff66] text-4xl font-bold px-2 rounded-md">
              Testimonials
            </h2>
            <p className="max-w-md text-gray-700">
              Hear from our satisfied clients about how our digital marketing
              services have helped their business grow.
            </p>
          </div>
        </div>
        
        <TestimonialSlider data={testimonials} />
      </section>

      <section className="max-w-7xl mx-auto py-20 px-4">
        <div className="flex items-center gap-4 mb-10">
          <h2 className="bg-[#b9ff66] text-3xl font-bold px-2 rounded-md">Contact Us</h2>
          <p className="text-gray-600">Connect with Us: Let's Discuss Your Digital Marketing Needs</p>
        </div>
        <ContactForm />
      </section>
    </main>
  );
}