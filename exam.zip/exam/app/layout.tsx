import { Space_Grotesk } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar"; // 1. Import Navbar
import Footer from "@/components/Footer"; // 2. Import Footer

// Configure the font
const spaceGrotesk = Space_Grotesk({ 
  subsets: ["latin"],
  weight: ['400', '500', '600', '700'], 
});

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={spaceGrotesk.className}>
        
        {children}

        {/* The Footer stays at the very bottom of every page */}
        <Footer />
      </body>
    </html>
  );
}