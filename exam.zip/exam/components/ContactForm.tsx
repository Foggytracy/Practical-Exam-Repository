"use client";
import { useState } from "react";
import { submitContactForm } from "@/app/actions/contact";

export default function ContactForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  async function clientAction(formData: FormData) {
    setStatus("loading");
    const result = await submitContactForm(formData);
    
    if (result.success) {
      setStatus("success");
    } else {
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="bg-[#F3F3F3] rounded-[45px] p-16 text-center border-2 border-black">
        <h2 className="text-3xl font-bold mb-4">Message Received!</h2>
        <p>Your inquiry has been logged in our system. Our team will review it shortly.</p>
        <button 
          onClick={() => setStatus("idle")}
          className="mt-6 bg-black text-white px-8 py-3 rounded-xl font-bold hover:bg-[#b9ff66] hover:text-black transition-colors"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <section className="bg-[#F3F3F3] rounded-[45px] p-8 md:p-16 relative overflow-hidden">
      <div className="grid md:grid-cols-2 gap-10">
        
        {/* Form Side */}
        <form action={clientAction} className="space-y-6 z-10">
          
          {/* Name Field */}
          <div>
            <label className="block mb-2 text-sm font-medium uppercase tracking-wider">Name</label>
            <input 
              name="name"
              type="text" 
              placeholder="Your Full Name"
              className="w-full border border-black rounded-xl p-4 bg-white focus:outline-[#b9ff66]"
              required
            />
          </div>

          {/* Email Field */}
          <div>
            <label className="block mb-2 text-sm font-medium uppercase tracking-wider">Email*</label>
            <input 
              name="email"
              type="email" 
              placeholder="Email Address"
              className="w-full border border-black rounded-xl p-4 bg-white focus:outline-[#b9ff66]"
              required
            />
          </div>

          {/* Message Field */}
          <div>
            <label className="block mb-2 text-sm font-medium uppercase tracking-wider">Message*</label>
            <textarea 
              name="message"
              placeholder="How can we help you?"
              rows={5}
              className="w-full border border-black rounded-xl p-4 bg-white focus:outline-[#b9ff66]"
              required
            ></textarea>
          </div>

          {/* Submit Button */}
          <button 
            type="submit" 
            disabled={status === "loading"}
            className="w-full bg-[#191a23] text-white py-4 rounded-xl font-bold hover:bg-[#b9ff66] hover:text-black transition-all disabled:bg-gray-400"
          >
            {status === "loading" ? "Processing..." : "Send Message"}
          </button>

          {status === "error" && (
            <p className="text-red-600 text-sm font-bold">Failed to send message. Please try again.</p>
          )}
        </form>

        {/* Illustration Side */}
        <div className="hidden md:flex justify-end items-center relative">
          <div className="absolute right-[-100px] top-0">
             <img src="/Contact us icon.svg" alt="Contact Illustration" />
          </div>
        </div>
      </div>
    </section>
  );
}