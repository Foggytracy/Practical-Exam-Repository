// components/CaseStudies.tsx

export default function CaseStudies({ data }: { data: any[] }) {
  return (
    <section className="mt-20">
      {/* Section Header */}
      <div className="flex items-center gap-4 mb-10">
        <h2 className="bg-[#b9ff66] text-3xl font-bold px-2 rounded-md">Case Studies</h2>
        <p className="text-gray-600 max-w-md">
          For a real-world demonstration of our expertise, explore our latest success stories.
        </p>
      </div>

      {/* Black Card Container */}
      <div className="bg-[#191a23] rounded-[45px] p-10 md:p-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 divide-y md:divide-y-0 md:divide-x divide-gray-600">
          {data.map((study) => (
            <div key={study.id} className="pt-10 md:pt-0 md:px-10 first:pl-0 last:pr-0 space-y-6">
              <p className="text-white text-lg leading-relaxed">
                {study.short_description}
              </p>
              
              {/* The "Learn More" Link */}
              <a 
                href={study.link_url || "#"} 
                className="text-[#b9ff66] flex items-center gap-3 hover:gap-5 transition-all duration-300 font-medium text-xl"
              >
                Learn more 
                <span className="text-2xl">→</span>
              </a>
            </div>
          ))}

          {data.length === 0 && (
            <p className="text-gray-500 italic">No case studies found in database.</p>
          )}
        </div>
      </div>
    </section>
  );
}