// components/Navbar.tsx
export default function Navbar() {
  return (
    <nav className="flex items-center justify-between py-6 bg-white">
      {/* Brand Logo Area */}
      <div className="flex items-center gap-2">
        <img src="/Icon.svg" alt="" className="w-8 h-8" /> 
        <span className="text-3xl font-bold tracking-tight">Positivus</span>
      </div>

      {/* Desktop Links - Hidden on Mobile */}
      <div className="hidden lg:flex items-center gap-8 text-lg">
        <a href="#" className="hover:underline decoration-brand-lime decoration-4 underline-offset-4">About us</a>
        <a href="#" className="hover:underline decoration-brand-lime decoration-4 underline-offset-4">Services</a>
        <a href="#" className="hover:underline decoration-brand-lime decoration-4 underline-offset-4">Use Cases</a>
        <a href="#" className="hover:underline decoration-brand-lime decoration-4 underline-offset-4">Pricing</a>
        <a href="#" className="hover:underline decoration-brand-lime decoration-4 underline-offset-4">Blog</a>
        <button className="border-2 border-brand-dark px-6 py-3 rounded-xl font-medium hover:bg-brand-dark hover:text-white transition-all">
          Request a quote
        </button>
      </div>

      {/* Mobile Menu Icon (You'll need this later) */}
      <div className="lg:hidden text-3xl">☰</div>
    </nav>
  );
}