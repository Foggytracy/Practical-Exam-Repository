interface TeamMember {
  id: string;
  name: string;
  role: string;
  experience: string;
  avatar_url: string;
}

export default function Team({ teamData }: { teamData: TeamMember[] }) {
  return (
    <section className="mt-[100px] mb-20 px-6 lg:px-20 max-w-[1440px] mx-auto">
      <div className="flex flex-col md:flex-row items-center gap-10 mb-20">
        <h2 className="bg-[#b9ff66] text-4xl font-bold px-2 rounded-md">Team</h2>
        <p className="max-w-xs text-gray-700">Meet the skilled team behind our digital strategies</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {teamData.map((member) => (
          <div key={member.id} className="border-2 border-black rounded-[45px] p-8 shadow-[0px_5px_0px_0px_rgba(0,0,0,1)] bg-white relative transition-all hover:translate-y-[-5px]">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-24 h-24 flex-shrink-0 overflow-hidden rounded-xl border-2 border-black">
                <img src={member.avatar_url} alt={member.name} className="w-full h-full object-cover" />
              </div>
              <div className="mt-auto pb-2">
                <h4 className="text-xl font-bold">{member.name}</h4>
                <p className="text-gray-600 text-sm">{member.role}</p>
              </div>
            </div>
            <hr className="border-black mb-6" />
            <p className="text-gray-800">{member.experience}</p>
          </div>
        ))}
      </div>
    </section>
  );
}