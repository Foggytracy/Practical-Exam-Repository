"use client";
import { useState } from 'react';

interface Testimonial {
  id: string;
  name: string;
  role_company: string;
  message: string;
  rating: number;
}

export default function TestimonialSlider({ data }: { data: Testimonial[] }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  if (!data || data.length === 0) return null;

  const nextSlide = () => setCurrentIndex((prev) => (prev === data.length - 1 ? 0 : prev + 1));
  const prevSlide = () => setCurrentIndex((prev) => (prev === 0 ? data.length - 1 : prev - 1));

  return (
    <section className="bg-[#191a23] rounded-[45px] py-16 px-6 overflow-hidden">
      <div className="max-w-4xl mx-auto relative">
        <div className="overflow-hidden">
          <div 
            className="flex transition-transform duration-500 ease-in-out" 
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {data.map((item) => (
              <div key={item.id} className="w-full flex-shrink-0 px-4">
                <div className="relative border border-[#b9ff66] rounded-[40px] p-8 md:p-12 text-white mb-10">
                  <p className="text-lg italic">"{item.message}"</p>
                  <div className="absolute -bottom-4 left-12 w-8 h-8 bg-[#191a23] border-l border-b border-[#b9ff66] rotate-[-45deg]"></div>
                </div>
                <div className="pl-16">
                  <h4 className="text-[#b9ff66] font-bold">{item.name}</h4>
                  <p className="text-white text-sm">{item.role_company}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center items-center gap-8 mt-12">
          <button onClick={prevSlide} className="text-white text-3xl hover:text-[#b9ff66]">←</button>
          <div className="flex gap-2">
            {data.map((_, i) => (
              <div key={i} className={`w-3 h-3 rotate-45 transition-all ${currentIndex === i ? 'bg-[#b9ff66]' : 'border border-white'}`} />
            ))}
          </div>
          <button onClick={nextSlide} className="text-white text-3xl hover:text-[#b9ff66]">→</button>
        </div>
      </div>
    </section>
  );
}