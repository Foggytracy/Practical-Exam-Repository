"use client";

import { useState } from "react";

interface ProcessStep {
  id: string;
  step_no: number;
  title: string;
  description: string;
}

export default function WorkingProcess({ data }: { data: ProcessStep[] }) {
  // Automatically open the first step (01) if data exists
  const [openStep, setOpenStep] = useState<number | null>(data[0]?.step_no || null);

  return (
    <section className="mt-[100px] mb-20 px-6 lg:px-20 max-w-[1440px] mx-auto">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row items-center gap-10 mb-20">
        <h2 className="bg-[#b9ff66] text-4xl font-bold px-2 rounded-md border-2 border-black">
          Our Working Process
        </h2>
        <p className="max-w-xs text-gray-700 font-medium">
          Step-by-Step Guide to Achieving Your Business Goals
        </p>
      </div>

      {/* Accordion List */}
      <div className="space-y-6">
        {data.map((step) => {
          const isOpen = openStep === step.step_no;
          
          return (
            <div 
              key={step.id}
              className={`rounded-[45px] border-2 border-black shadow-[0px_5px_0px_0px_rgba(0,0,0,1)] transition-all duration-300 ${
                isOpen ? 'bg-[#b9ff66]' : 'bg-[#f3f3f3]'
              }`}
            >
              {/* Header / Trigger */}
              <button 
                onClick={() => setOpenStep(isOpen ? null : step.step_no)}
                className="w-full flex items-center justify-between p-8 md:p-10 text-left"
              >
                <div className="flex items-center gap-6">
                  {/* Leading Zero Logic */}
                  <span className="text-4xl md:text-6xl font-bold">
                    {step.step_no < 10 ? `0${step.step_no}` : step.step_no}
                  </span>
                  <span className="text-xl md:text-3xl font-bold">{step.title}</span>
                </div>
                
                {/* Plus/Minus Icon */}
                <div className="w-12 h-12 rounded-full border-2 border-black bg-white flex items-center justify-center text-3xl font-bold shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                  {isOpen ? "−" : "+"}
                </div>
              </button>

              {/* Content Area */}
              {isOpen && (
                <div className="px-8 md:px-10 pb-10">
                  <hr className="border-black mb-8" />
                  <p className="text-lg md:text-xl leading-relaxed text-black">
                    {step.description}
                  </p>
                </div>
              )}
            </div>
          );
        })}

        {/* Empty State */}
        {data.length === 0 && (
          <div className="p-10 text-center border-2 border-dashed border-gray-400 rounded-[45px]">
            <p className="text-gray-500 italic text-lg">
              No process steps added in the admin dashboard yet.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}