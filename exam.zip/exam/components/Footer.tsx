import Image from "next/image";
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-[#191a23] text-white rounded-t-[45px] px-6 py-12 md:px-16 mt-20">
      <div className="max-w-7xl mx-auto">
        
        {/* Top Row: Logo and Nav */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-16">
          <div className="flex items-center gap-2">
            {/* Replace with your exported Logo SVG */}
            <div className="text-2xl font-bold flex items-center gap-2">
              <span className="bg-white w-6 h-6 rotate-45 inline-block"></span>
              Positivus
            </div>
          </div>
          
          <nav className="flex flex-wrap justify-center gap-6 underline decoration-1 underline-offset-4">
            <Link href="#">About us</Link>
            <Link href="#">Services</Link>
            <Link href="#">Use Cases</Link>
            <Link href="#">Pricing</Link>
            <Link href="#">Blog</Link>
          </nav>

          <div className="flex gap-4">
            {/* Social Icons - use FontAwesome or HeroIcons if allowed, otherwise simple circles */}
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-black font-bold">in</div>
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-black font-bold">f</div>
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-black font-bold">t</div>
          </div>
        </div>

        {/* Middle Row: Contact and Newsletter */}
        <div className="grid md:grid-cols-2 gap-12 items-center border-b border-white/20 pb-12 mb-8">
          
          <div className="space-y-4">
            <h3 className="bg-[#b9ff66] text-black font-bold px-2 rounded-md inline-block">Contact us:</h3>
            <p className="mt-4">Email: info@positivus.com</p>
            <p>Phone: 555-567-8901</p>
            <p className="max-w-xs">Address: 1234 Main St Moonstone City, Stardust State 12345</p>
          </div>

          {/* Newsletter Box */}
          <div className="bg-[#292A32] p-8 rounded-[14px] flex flex-col lg:flex-row gap-4">
            <input 
              type="email" 
              placeholder="Email" 
              className="bg-transparent border border-white rounded-xl p-4 flex-grow focus:outline-[#b9ff66]"
            />
            <button className="bg-[#b9ff66] text-black font-bold px-8 py-4 rounded-xl hover:bg-white transition-colors">
              Subscribe to news
            </button>
          </div>
        </div>

        {/* Bottom Row: Copyright */}
        <div className="flex flex-col md:flex-row gap-4 text-sm">
          <p>© 2023 Positivus. All Rights Reserved.</p>
          <Link href="#" className="underline">Privacy Policy</Link>
        </div>
      </div>
    </footer>
  );
}