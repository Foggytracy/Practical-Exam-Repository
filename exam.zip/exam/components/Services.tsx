// components/Services.tsx
import Image from "next/image";

interface ServiceFromDB {
  id: number;
  title: string;
  description: string; // We'll use this for the subtitle/description
}

interface ServicesProps {
  dbServices: ServiceFromDB[];
}

export default function Services({ dbServices }: ServicesProps) {
  // Brand style cycles to keep the UI looking like your original design
  const styles = [
    { color: "bg-brand-gray", textColor: "bg-brand-lime", dark: false },
    { color: "bg-brand-lime", textColor: "bg-white", dark: false },
    { color: "bg-brand-dark", textColor: "bg-white", dark: true },
  ];

  return (
    <section className="py-20 max-w-7xl mx-auto px-4">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row items-center gap-10 mb-20">
        <h2 className="bg-brand-lime text-4xl font-bold px-2 rounded-md">Services</h2>
        <p className="max-w-xl text-gray-700">
          At our digital marketing agency, we offer a range of services to help businesses grow and succeed online.
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {dbServices.map((service, i) => {
          // Cycle through the 3 brand styles based on index
          const style = styles[i % styles.length];
          
          return (
            <div 
              key={service.id} 
              className={`${style.color} p-12 rounded-brand border border-brand-dark shadow-brutal flex justify-between items-stretch`}
            >
              <div className="flex flex-col justify-between">
                <div className="space-y-1">
                  <span className={`${style.textColor} text-3xl font-bold px-1 rounded-sm block w-fit text-black`}>
                    {service.title}
                  </span>
                  <p className={`mt-2 max-w-[200px] ${style.dark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {service.description}
                  </p>
                </div>
                
                <div className="flex items-center gap-4 mt-10 group cursor-pointer">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${style.dark ? 'bg-white text-brand-dark' : 'bg-brand-dark text-brand-lime'}`}>
                    <span className="text-2xl rotate-45">↑</span>
                  </div>
                  <span className={`text-xl font-medium ${style.dark ? 'text-white' : 'text-black'}`}>Learn more</span>
                </div>
              </div>

              <div className="flex items-center">
                {/* Fallback image if you haven't set up image uploads yet */}
                <img src="/services/search engine.svg" alt={service.title} className="w-52 h-44 object-contain" />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}