import 'server-only';

import { Pool } from 'pg';

// This prevents Next.js from creating multiple pools during development
const globalForPg = global as unknown as { pool: Pool };

export const pool =
  globalForPg.pool ||
  new Pool({
    connectionString: process.env.DATABASE_URL,
    // Add these for better stability:
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
  });

if (process.env.NODE_ENV !== 'production') globalForPg.pool = pool;

export const query = (text: string, params?: any[]) => pool.query(text, params);

console.log("DB URL Check:", process.env.DATABASE_URL ? "Found" : "NOT FOUND");