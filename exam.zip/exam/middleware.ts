import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "your_super_secret_exam_key_123"
);

export async function middleware(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value;
  const isAdminPage = request.nextUrl.pathname.startsWith('/admin');

  if (isAdminPage) {
    // 1. If no token, redirect to login
    if (!token) {
      return NextResponse.redirect(new URL('/login', request.url));
    }

    try {
      // 2. Verify the JWT
      await jwtVerify(token, SECRET);
      
      const response = NextResponse.next();
      
      // 3. IMPORTANT: Prevent browser caching of admin pages
      response.headers.set('Cache-Control', 'no-store, max-age=0');
      
      return response;
    } catch (err) {
      // 4. If token is invalid/expired
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};